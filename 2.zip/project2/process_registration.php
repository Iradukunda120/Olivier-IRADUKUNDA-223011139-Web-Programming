<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Default WAMP username
$password = ""; // Default WAMP password (empty)
$dbname = "student_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $day = (int)$_POST['day'];
    $month = mysqli_real_escape_string($conn, $_POST['month']);
    $year = (int)$_POST['year'];
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $pin_code = mysqli_real_escape_string($conn, $_POST['pin_code']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $country = mysqli_real_escape_string($conn, $_POST['country']);

    // Handle hobbies (checkboxes)
    $hobbies = isset($_POST['hobbies']) ? implode(", ", $_POST['hobbies']) : "";
    if (isset($_POST['other_hobby']) && !empty($_POST['other_hobby'])) {
        $hobbies .= (!empty($hobbies) ? ", " : "") . mysqli_real_escape_string($conn, $_POST['other_hobby']);
    }

    $course = mysqli_real_escape_string($conn, $_POST['course']);

    // Prepare SQL statement
    $sql = "INSERT INTO students (first_name, last_name, day, month, year, email, mobile, gender, address, city, pin_code, state, country, hobbies, course)
            VALUES ('$first_name', '$last_name', $day, '$month', $year, '$email', '$mobile', '$gender', '$address', '$city', '$pin_code', '$state', '$country', '$hobbies', '$course')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        header("Location: work2.php?success=1");
        exit();
    } else {
        header("Location: work2.php?error=" . urlencode($conn->error));
        exit();
    }
}

// Close connection
$conn->close();
?></content>
<parameter name="filePath">c:\wamp64\www\project2\process_registration.php
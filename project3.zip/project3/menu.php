﻿<?php
session_start();
$page_title = "Menu";

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$menuCategories = [
    [
        'slug' => 'breakfast',
        'name' => 'Breakfast',
        'description' => 'Start your day with fresh morning meals and brewed coffee.',
        'image' => 'images/menu/breakfast.jpg',
        'items' => [
            ['name' => 'Continental Breakfast', 'description' => 'Pastries, toast, fruit, coffee or tea.', 'price' => 15.99],
            ['name' => 'African Breakfast', 'description' => 'Local staples with fresh eggs, beans and tea.', 'price' => 17.99],
            ['name' => 'Pancake Platter', 'description' => 'Fluffy pancakes with syrup and berries.', 'price' => 14.99],
        ],
    ],
    [
        'slug' => 'lunch',
        'name' => 'Lunch',
        'description' => 'Delicious lunch options with local and international cuisine.',
        'image' => 'images/menu/lunch.jpg',
        'items' => [
            ['name' => 'Grilled Chicken Lunch', 'description' => 'Marinated chicken with rice and salad.', 'price' => 24.99],
            ['name' => 'Beef Brochette', 'description' => 'Traditional brochettes with chips and veggies.', 'price' => 26.99],
            ['name' => 'Vegetarian Curry', 'description' => 'Creamy vegetable curry served with rice.', 'price' => 22.99],
        ],
    ],
    [
        'slug' => 'dinner',
        'name' => 'Dinner',
        'description' => 'Gourmet dinner dishes for a relaxing evening.',
        'image' => 'images/menu/dinner.jpg',
        'items' => [
            ['name' => 'Steak Dinner', 'description' => 'Grilled steak with mashed potatoes and greens.', 'price' => 32.99],
            ['name' => 'Seafood Platter', 'description' => 'Fresh seafood selection with garlic butter.', 'price' => 38.99],
            ['name' => 'Pasta Dinner', 'description' => 'Creamy pasta with herbs and parmesan.', 'price' => 28.99],
        ],
    ],
    [
        'slug' => 'drinks',
        'name' => 'Drinks',
        'description' => 'Refreshing drinks to complement your meal.',
        'image' => 'images/gallery/softdrink.jpeg',
        'items' => [
            ['name' => 'Fresh Juice', 'description' => 'Seasonal fruit juices made to order.', 'price' => 5.99],
            ['name' => 'Mocktail', 'description' => 'Refreshing non-alcoholic cocktails.', 'price' => 7.99],
            ['name' => 'Soft Drink', 'description' => 'Cold carbonated soft drinks.', 'price' => 3.99],
        ],
    ],
    [
        'slug' => 'desserts',
        'name' => 'Desserts',
        'description' => 'Sweet treats to complete your meal.',
        'image' => 'images/menu/cake.jpg',
        'items' => [
            ['name' => 'Chocolate Cake', 'description' => 'Rich chocolate layered cake.', 'price' => 6.99],
            ['name' => 'Ice Cream', 'description' => 'Premium ice cream with multiple flavors.', 'price' => 4.99],
            ['name' => 'Fruit Salad', 'description' => 'Fresh seasonal fruits with honey.', 'price' => 5.49],
        ],
    ],
];

$selectedCategory = '';
if (isset($_GET['category'])) {
    $selectedCategory = trim(strtolower($_GET['category']));
} elseif (isset($_GET['meal'])) {
    $selectedCategory = trim(strtolower($_GET['meal']));
} elseif (!empty($_GET)) {
    $getKeys = array_keys($_GET);
    if (count($getKeys) === 1) {
        $key = $getKeys[0];
        if ($key === '') {
            $selectedCategory = trim(strtolower($_GET[$key]));
        } else {
            $selectedCategory = trim(strtolower($key));
        }
    }
}

$categoryData = null;
foreach ($menuCategories as $category) {
    if ($category['slug'] === $selectedCategory) {
        $categoryData = $category;
        break;
    }
}

$showMessage = '';
if (isset($_POST['add_to_cart']) && isset($_POST['items'])) {
    foreach ($_POST['items'] as $key => $value) {
        $qty = isset($_POST['qty'][$key]) ? max(1, (int)$_POST['qty'][$key]) : 1;
        $price = isset($_POST['price'][$key]) ? (float)$_POST['price'][$key] : 0;
        if ($qty > 0) {
            $_SESSION['cart'][] = [
                'name' => $value,
                'qty' => $qty,
                'price' => $price
            ];
        }
    }
    $showMessage = 'Item added to cart. Continue choosing meals or proceed to checkout.';
}

$cartCount = 0;
$cartTotal = 0.0;
foreach ($_SESSION['cart'] as $cartItem) {
    $cartCount += isset($cartItem['qty']) ? (int)$cartItem['qty'] : 1;
    $cartTotal += (isset($cartItem['qty']) ? (int)$cartItem['qty'] : 1) * (isset($cartItem['price']) ? (float)$cartItem['price'] : 0);
}

include "includes/header.php";
?>

<style>
    /* Menu Page Specific Styles */
    .menu-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 40px 20px;
    }

    .menu-header {
        text-align: center;
        margin-bottom: 50px;
    }

    .menu-header h2 {
        font-size: 2.5rem;
        color: #8b6f47;
        margin-bottom: 10px;
    }

    .menu-header p {
        color: #666;
        font-size: 1.1rem;
    }

    .cart-summary {
        background: #ffffff;
        border-radius: 14px;
        padding: 20px;
        margin-bottom: 30px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }
    .cart-summary h3 {
        margin-bottom: 10px;
        color: #8b6f47;
    }
    .cart-summary p {
        margin: 6px 0;
        color: #555;
    }
    .cart-summary a {
        display: inline-block;
        margin-top: 12px;
        background: #8b6f47;
        color: white;
        padding: 10px 18px;
        border-radius: 24px;
        text-decoration: none;
    }

    .menu-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        margin-top: 20px;
    }

    .menu-card {
        background: #ffffff;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s, box-shadow 0.3s;
        border: 1px solid #eee;
    }

    .menu-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }

    .menu-image {
        width: 100%;
        height: 220px;
        overflow: hidden;
        background: #f5f5f5;
    }

    .menu-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s;
    }

    .menu-card:hover .menu-image img {
        transform: scale(1.05);
    }

    .menu-info {
        padding: 20px;
        text-align: center;
    }

    .menu-info h3 {
        color: #8b6f47;
        font-size: 1.5rem;
        margin-bottom: 10px;
    }

    .menu-info p {
        color: #666;
        margin-bottom: 15px;
        line-height: 1.5;
    }

    .menu-price {
        font-size: 1.3rem;
        font-weight: bold;
        color: #8b6f47;
        margin-bottom: 15px;
    }

    .order-btn {
        display: inline-block;
        background: #8b6f47;
        color: white;
        padding: 10px 25px;
        border-radius: 25px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s;
    }

    .order-btn:hover {
        background: #6b5335;
        transform: translateY(-2px);
    }

    .category-card {
        position: relative;
        overflow: hidden;
    }
    .category-card .category-link {
        display: block;
        width: 100%;
        height: 100%;
        color: inherit;
        text-decoration: none;
    }
    .category-card .category-overlay {
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.4);
        color: white;
        padding: 25px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        gap: 8px;
    }
    .category-card .category-overlay h3 {
        margin: 0;
        font-size: 1.8rem;
    }
    .category-card .category-overlay p {
        margin: 0;
        color: #f5f5f5;
        font-size: 1rem;
    }

    .menu-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        justify-content: center;
        margin-top: 20px;
    }

    .menu-actions a {
        background: #8b6f47;
        color: white;
        padding: 10px 22px;
        border-radius: 24px;
        text-decoration: none;
        font-weight: 600;
    }

    .field-qty {
        margin-bottom: 10px;
        width: 70px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .menu-grid {
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .menu-image {
            height: 180px;
        }

        .menu-header h2 {
            font-size: 2rem;
        }
    }
</style>

<div class="menu-container">
    <div class="menu-header">
        <h2>🍽️ Our Premium Menu</h2>
        <p>Choose a meal category and select the items you want.</p>
    </div>

    <?php if ($cartCount > 0): ?>
        <div class="cart-summary">
            <h3>🛒 Current Cart</h3>
            <?php if ($showMessage): ?>
                <p><?php echo htmlspecialchars($showMessage); ?></p>
            <?php else: ?>
                <p>Continue choosing meals or proceed to checkout when you're ready.</p>
            <?php endif; ?>
            <p><strong><?php echo $cartCount; ?> item(s)</strong> in cart, total <strong>$<?php echo number_format($cartTotal, 2); ?></strong>.</p>
            <a href="order_form.php">Proceed to Checkout</a>
        </div>
    <?php endif; ?>

    <?php if (!$categoryData): ?>
        <div class="menu-grid">
            <?php foreach ($menuCategories as $category): ?>
                <div class="menu-card category-card">
                    <a class="category-link" href="menu.php?category=<?php echo $category['slug']; ?>">
                        <div class="menu-image">
                            <img src="<?php echo $category['image']; ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" onerror="this.src='images/placeholder.jpg'">
                        </div>
                        <div class="category-overlay">
                            <h3><?php echo htmlspecialchars($category['name']); ?></h3>
                            <p><?php echo htmlspecialchars($category['description']); ?></p>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="menu-actions">
            <a href="menu.php">Browse All Categories</a>
            <a href="order_form.php">Checkout</a>
        </div>
        <div class="menu-header">
            <h2>🍽️ <?php echo htmlspecialchars($categoryData['name']); ?> Menu</h2>
            <p><?php echo htmlspecialchars($categoryData['description']); ?></p>
        </div>
        <div class="menu-grid">
            <?php foreach ($categoryData['items'] as $index => $item): ?>
                <div class="menu-card">
                    <div class="menu-image">
                        <img src="<?php echo $categoryData['image']; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" onerror="this.src='images/placeholder.jpg'">
                    </div>
                    <div class="menu-info">
                        <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                        <p><?php echo htmlspecialchars($item['description']); ?></p>
                        <div class="menu-price">$<?php echo number_format($item['price'], 2); ?></div>
                        <form method="POST" action="menu.php?category=<?php echo $categoryData['slug']; ?>" style="display: inline;">
                            <input type="hidden" name="items[<?php echo $index; ?>]" value="<?php echo htmlspecialchars($item['name']); ?>">
                            <input type="number" name="qty[<?php echo $index; ?>]" value="1" min="1" class="field-qty">
                            <input type="hidden" name="price[<?php echo $index; ?>]" value="<?php echo $item['price']; ?>">
                            <input type="hidden" name="add_to_cart" value="1">
                            <button type="submit" class="order-btn" style="border: none; cursor: pointer; font-family: inherit;">Add to Cart</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const images = document.querySelectorAll('.menu-image img');
        images.forEach(img => {
            img.addEventListener('error', function() {
                this.src = 'images/placeholder.jpg';
                this.alt = 'Image not available';
            });
        });
    });
</script>

<?php include "includes/footer.php"; ?>

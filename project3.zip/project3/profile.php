<?php
session_start();
include "connect.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$fullname = $_SESSION['fullname'];

// Get user info
$user_query = "SELECT * FROM users WHERE id = ?";
$user_result = executeQuery($user_query, [$user_id]);

if (!$user_result['success'] || !$user_result['result']) {
    die('Unable to load user profile. ' . htmlspecialchars($user_result['error'] ?? '')); 
}

$user = $user_result['result']->fetch_assoc();
if (!$user) {
    die('User not found.');
}

// Get all bookings with invoice info
$bookings_query = "SELECT b.*, i.id AS invoice_id, i.invoice_number
                   FROM bookings b
                   LEFT JOIN invoices i ON b.id = i.booking_id
                   WHERE b.user_id = ?
                   ORDER BY b.created_at DESC";
$bookings_result = executeQuery($bookings_query, [$user_id]);
if (!$bookings_result['success'] || !$bookings_result['result']) {
    $bookings_result['success'] = false;
    $bookings_result['result'] = null;
}

// Get payment statistics
 $stats_query = "SELECT 
                    COUNT(*) as total_bookings,
                    SUM(b.total_price) as total_spent,
                    COUNT(CASE WHEN b.status='Completed' THEN 1 END) as completed,
                    COUNT(DISTINCT i.id) as total_invoices
                FROM bookings b
                LEFT JOIN invoices i ON b.id = i.booking_id
                WHERE b.user_id = ?";
$stats_result = executeQuery($stats_query, [$user_id]);

if (!$stats_result['success'] || !$stats_result['result']) {
    $stats = ['total_bookings' => 0, 'total_spent' => 0, 'completed' => 0, 'total_invoices' => 0];
} else {
    $stats = $stats_result['result']->fetch_assoc() ?: ['total_bookings' => 0, 'total_spent' => 0, 'completed' => 0, 'total_invoices' => 0];
}

// Cancel booking
if (isset($_POST['cancel_booking'])) {
    $booking_id = $_POST['booking_id'];
    $update_query = "UPDATE bookings SET status = 'Cancelled' WHERE id = ? AND user_id = ?";
    executeQuery($update_query, [$booking_id, $user_id]);
    header("Location: profile.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | MO Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding-top: 80px;
        }
        .container {
            max-width: 1100px;
            margin: 30px auto;
            padding: 20px;
        }
        
        .profile-header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .profile-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .info-card {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #8b6f47;
        }
        .info-card h3 {
            color: #666;
            font-size: 13px;
            margin-bottom: 10px;
        }
        .info-card p {
            font-size: 18px;
            font-weight: bold;
            color: #8b6f47;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-box h4 {
            color: #666;
            margin-bottom: 10px;
        }
        .stat-box .number {
            font-size: 32px;
            font-weight: bold;
            color: #8b6f47;
        }
        
        .bookings-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .bookings-section h2 {
            color: #8b6f47;
            margin-bottom: 20px;
            border-bottom: 2px solid #8b6f47;
            padding-bottom: 10px;
        }
        
        .booking-item {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid #4CAF50;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .booking-item.cancelled {
            border-left-color: #dc3545;
            opacity: 0.6;
        }
        .booking-item.pending {
            border-left-color: #ffc107;
        }
        .booking-details {
            flex-grow: 1;
        }
        .booking-details h4 {
            color: #8b6f47;
            margin-bottom: 5px;
        }
        .booking-details p {
            font-size: 13px;
            color: #666;
            margin: 3px 0;
        }
        .booking-status {
            background: #4CAF50;
            color: white;
            padding: 8px 12px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: bold;
            margin: 0 10px;
        }
        .booking-status.pending {
            background: #ffc107;
            color: #333;
        }
        .booking-status.cancelled {
            background: #dc3545;
        }
        
        .actions {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
        }
        .btn-primary {
            background: #8b6f47;
            color: white;
        }
        .btn-primary:hover {
            background: #6b5436;
        }
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        .btn-danger:hover {
            background: #c82333;
        }
        
        .empty-message {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        
        .footer {
            background: #8b6f47;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <!-- NAVBAR -->
    <!-- ================= NAVBAR ================= -->
    <div class="navbar">

        <div class="logo">
            <h2>MO Hotel</h2>
        </div>

        <div class="menu">
            <a href="dashboard.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="menu.php">Menu</a>
            <a href="order.php">Order</a>
            <a href="gallery.php">Gallery</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="auth">
            <span>Hello, <?php echo htmlspecialchars($fullname); ?></span>
            <a href="logout.php">Logout</a>
        </div>

    </div>

    <!-- MAIN CONTENT -->
    <div class="container">
        
        <!-- PROFILE HEADER -->
        <div class="profile-header">
            <h1>👤 My Profile</h1>
            <div class="profile-info" style="margin-top: 20px;">
                <div class="info-card">
                    <h3>Full Name</h3>
                    <p><?php echo htmlspecialchars($user['fullname']); ?></p>
                </div>
                <div class="info-card">
                    <h3>Email</h3>
                    <p><?php echo htmlspecialchars($user['email']); ?></p>
                </div>
                <div class="info-card">
                    <h3>Phone</h3>
                    <p><?php echo htmlspecialchars($user['phone'] ?? 'Not provided'); ?></p>
                </div>
                <div class="info-card">
                    <h3>Member Since</h3>
                    <p><?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>
        </div>

        <!-- STATISTICS -->
        <div class="stats">
            <div class="stat-box">
                <h4>📦 Total Bookings</h4>
                <div class="number"><?php echo $stats['total_bookings']; ?></div>
            </div>
            <div class="stat-box">
                <h4>✅ Completed</h4>
                <div class="number"><?php echo $stats['completed']; ?></div>
            </div>
            <div class="stat-box">
                <h4>🧾 Invoices</h4>
                <div class="number"><?php echo $stats['total_invoices'] ?? 0; ?></div>
            </div>
            <div class="stat-box">
                <h4>💰 Total Spent</h4>
                <div class="number">$<?php echo number_format($stats['total_spent'] ?? 0, 2); ?></div>
            </div>
        </div>

        <!-- BOOKINGS -->
        <div class="bookings-section">
            <h2>📋 My Bookings</h2>
            
            <?php if ($bookings_result['success'] && $bookings_result['result']->num_rows > 0): ?>
                <?php while ($booking = $bookings_result['result']->fetch_assoc()): ?>
                    <div class="booking-item <?php echo strtolower($booking['status']); ?>">
                        <div class="booking-details">
                            <h4><?php echo htmlspecialchars($booking['item_name']); ?></h4>
                            <p>📅 Date: <?php echo $booking['booking_date']; ?></p>
                            <p>📊 Quantity: <?php echo $booking['quantity']; ?></p>
                            <p>💵 Total: $<?php echo number_format($booking['total_price'], 2); ?></p>
                            <?php if ($booking['notes']): ?>
                                <p>📝 Notes: <?php echo htmlspecialchars($booking['notes']); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="booking-status <?php echo strtolower($booking['status']); ?>">
                            <?php echo $booking['status']; ?>
                        </div>
                        <div class="actions">
                            <?php if (!empty($booking['invoice_number'])): ?>
                                <a href="invoices.php?id=<?php echo $booking['invoice_id']; ?>" class="btn btn-primary">View Invoice</a>
                            <?php elseif ($booking['status'] == 'Pending'): ?>
                                <a href="checkout.php?booking_id=<?php echo $booking['id']; ?>" class="btn btn-primary">Pay Now</a>
                            <?php endif; ?>

                            <?php if ($booking['status'] == 'Pending'): ?>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Cancel this booking?');">
                                    <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                    <button type="submit" name="cancel_booking" class="btn btn-danger">Cancel</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-message">
                    <p>📭 No bookings yet. <a href="dashboard.php">Start booking now!</a></p>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <script src="active-nav.js"></script>

    <?php include "includes/footer.php"; ?>

</body>
</html>


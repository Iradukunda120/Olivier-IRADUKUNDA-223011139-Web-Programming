<?php
session_start();
include "connect.php";

$page_title = "Gallery";

// Get fullname from session
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';
$initial = substr($fullname, 0, 1) . '.';

$gallery = [

    ["img" => "backimage.jpeg", "title" => "Hotel View", "category" => "hotel"],
    ["img" => "backview.jpeg", "title" => "Scenic View", "category" => "hotel"],
    ["img" => "conference.jpeg", "title" => "Conference Hall", "category" => "hall"],
    ["img" => "conference1.jpeg", "title" => "Premium Hall", "category" => "hall"],
    ["img" => "kitchen 1.jpeg", "title" => "Kitchen", "category" => "food"],
    ["img" => "luxuryroom.jpeg", "title" => "Luxury Room", "category" => "room"],
    ["img" => "regularroom.jpeg", "title" => "Standard Room", "category" => "room"],
    ["img" => "vvip.jpeg", "title" => "VVIP Room", "category" => "room"],
    ["img" => "vvip1.jpeg", "title" => "Presidential Suite", "category" => "room"],
    ["img" => "softdrink.jpeg", "title" => "Drinks", "category" => "food"],
    ["img" => "softdrink1.jpeg", "title" => "Fresh Drinks", "category" => "food"],
    ["img" => "reception.jpeg", "title" => "Reception", "category" => "hotel"]

];

$grouped = [];

foreach ($gallery as $item) {
    $grouped[$item['category']][] = $item;
}

include "includes/header.php";
?>

    <style>
        body {
            font-family: Arial;
            margin: 0;
            background: #f5f5f5;
            color: #222;
        }

        h2 {
            text-align: center;
            margin-top: 30px;
            color: #222;
        }

        .slider-box {
            width: 80%;
            margin: 20px auto;
            background: #fff;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .slider-box img {
            width: 100%;
            height: 350px;
            object-fit: cover;
            border-radius: 10px;
            filter: none !important;
            opacity: 1;
            transition: opacity 0.5s ease;
        }

        .caption {
            margin-top: 10px;
            font-weight: bold;
            color: #222;
        }

        .footer {
            background: #0b5b9a;
            color: white;
            padding: 30px;
            margin-top: 40px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .footer a {
            color: #ddd;
            text-decoration: none;
            display: block;
            margin: 5px 0;
        }

        .footer a:hover {
            color: #fff;
        }
    </style>

</head>

<body>

    <?php foreach ($grouped as $category => $items): ?>

        <h2><?= ucfirst($category) ?></h2>

        <div class="slider-box">

            <img id="img-<?= $category ?>" src="images/gallery/<?= $items[0]['img'] ?>">

            <div class="caption" id="text-<?= $category ?>">
                <?= $items[0]['title'] ?>
            </div>

        </div>

        <script>
            let <?= $category ?>Index = 0;

            let <?= $category ?>Images = [
                <?php foreach ($items as $item): ?> {
                        img: "images/gallery/<?= $item['img'] ?>",
                        title: "<?= $item['title'] ?>"
                    },
                <?php endforeach; ?>
            ];

            function rotate_<?= $category ?>() {

                let img = document.getElementById("img-<?= $category ?>");
                let text = document.getElementById("text-<?= $category ?>");

                let list = <?= $category ?>Images;

                img.style.opacity = 0;

                setTimeout(() => {

                    <?= $category ?>Index = (<?= $category ?>Index + 1) % list.length;

                    img.src = list[<?= $category ?>Index].img;
                    text.innerHTML = list[<?= $category ?>Index].title;

                    img.style.opacity = 1;

                }, 400);
            }

            setInterval(rotate_<?= $category ?>, 3000);
        </script>

    <?php endforeach; ?>

<?php include "includes/footer.php"; ?>
<?php
session_start();

$page_title = "Shopping Cart";

$userLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['email']);
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';
$guestWarning = '';
$showLoginPopup = false;
$popupTitle = '';

include "includes/header.php";

/* INIT CART */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

/* DELETE ITEM */
if (isset($_POST['delete'])) {
    $index = $_POST['delete'];

    unset($_SESSION['cart'][$index]);
    $_SESSION['cart'] = array_values($_SESSION['cart']);
}

/* UPDATE ITEM */
if (isset($_POST['update'])) {
    $index = $_POST['index'];
    $qty = (int)$_POST['qty'];

    if ($qty < 1) $qty = 1;

    $_SESSION['cart'][$index]['qty'] = $qty;
}

/* CHECKOUT */
$selectedTotal = 0;
$selectedItems = [];

if (isset($_POST['checkout'])) {
    if (empty($_POST['select'])) {
        $guestWarning = 'Please select at least one item to checkout.';
        $popupTitle = 'Selection Required';
        $showLoginPopup = true;
    } elseif (!$userLoggedIn) {
        $guestWarning = 'Please login or register before checking out.';
        $popupTitle = 'Login Required';
        $showLoginPopup = true;
    } else {
        $_SESSION['selected_items'] = $_POST['select'];
        header("Location: order_form.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Cart | MO Hotel</title>
    <link rel="stylesheet" href="css/style.css">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            font-family: Arial;
            background: #f5f5f5;
            margin: 0;
            padding-top: 80px;
        }

        /* HIDE DUPLICATE HEADER */
        .header {
            display: none;
        }

        .header a {
            background: #4CAF50;
            padding: 8px 15px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .container {
            width: 90%;
            margin: 20px auto;
        }

        .card {
            background: white;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
        }

        .row {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        input[type="number"] {
            width: 70px;
            padding: 5px;
        }

        .btn {
            padding: 6px 10px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            color: white;
        }

        .update {
            background: orange;
        }

        .delete {
            background: red;
        }

        .checkout {
            background: green;
        }

        /* WARM FOOTER */
        .footer {
            background: #8b6f47;
            color: white;
            padding: 30px;
            margin-top: 40px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .footer a {
            color: #ddd;
            text-decoration: none;
            display: block;
            margin: 5px 0;
        }

        .footer a:hover {
            color: #fff;
        }
    </style>
</head>

<body>

    <div class="container">

        <form method="POST" id="cartForm">
            <input type="hidden" name="update" value="">
            <input type="hidden" name="delete" value="">
            <input type="hidden" name="index" value="">
            <input type="hidden" name="qty" value="">

            <?php
            $total = 0;
            $validCart = [];

            foreach ($_SESSION['cart'] as $i => $item) {
                if (is_array($item) && isset($item['name'], $item['price'], $item['qty'])) {
                    $validCart[$i] = $item;
                }
            }

            if (empty($validCart)) {
                echo "<p>Your cart is empty.</p>";
            } else {

                foreach ($validCart as $i => $item) {
                    $subtotal = (float)$item['qty'] * (float)$item['price'];
                    $total += $subtotal;
            ?>

                    <div class="card">

                        <input type="checkbox" name="select[]" value="<?= $i ?>">

                        <h3><?= $item['name'] ?></h3>

                        <p>Price: $<?= $item['price'] ?></p>

                        <p>Subtotal: <b>$<?= $subtotal ?></b></p>

                        <div class="row">

                            <button type="button" class="btn update"
                                onclick="triggerUpdate(<?= $i ?>, <?= $item['qty'] ?>)">
                                🔄 Update
                            </button>

                            <button type="button" class="btn delete"
                                onclick="triggerDelete(<?= $i ?>)">
                                🗑 Delete
                            </button>

                        </div>

                    </div>

            <?php
                }

                echo "<div class='card'><b>Total: $$total</b></div>";
            }
            ?>

            <br>

            <button type="submit" name="checkout" class="btn checkout">
                ✅ Checkout Selected
            </button>

        </form>

        <?php if ($showLoginPopup): ?>
            <div id="guestPopup" style="position:fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.55); display:flex; justify-content:center; align-items:center; z-index:999;">
                <div class="popup-box" style="background:white; padding:24px; border-radius:16px; max-width:420px; text-align:center;">
                    <h2><?php echo htmlspecialchars($popupTitle ?: 'Attention'); ?></h2>
                    <p><?php echo htmlspecialchars($guestWarning); ?></p>
                    <?php if ($popupTitle === 'Selection Required'): ?>
                        <p>Select an item and then click Checkout Selected.</p>
                    <?php else: ?>
                        <p>Please <a href="login.php">Login</a> or <a href="register.php">Register</a> to continue.</p>
                    <?php endif; ?>
                    <button type="button" onclick="closeGuestPopup()" class="btn" style="background:#333; margin-top:16px;">Close</button>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <script>
        function closeGuestPopup() {
            const popup = document.getElementById('guestPopup');
            if (popup) popup.style.display = 'none';
        }

        function triggerDelete(i) {
            Swal.fire({
                title: "Delete Item?",
                text: "This item will be removed.",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33"
            }).then((result) => {
                if (result.isConfirmed) {
                    const form = document.getElementById('cartForm');
                    form.delete.value = 1;
                    form.index.value = i;
                    form.submit();
                }
            });
        }

        function triggerUpdate(i, currentQty) {
            Swal.fire({
                title: "Update Quantity",
                input: "number",
                inputValue: currentQty,
                inputAttributes: {
                    min: 1
                },
                showCancelButton: true
            }).then((result) => {
                if (result.isConfirmed) {
                    const qty = parseInt(result.value, 10) || currentQty;
                    const form = document.getElementById('cartForm');
                    form.update.value = 1;
                    form.index.value = i;
                    form.qty.value = qty;
                    form.submit();
                }
            });
        }
    </script>

    <?php include "includes/footer.php"; ?>

/**
 * MO Hotel - Active Navigation Link Handler
 * Automatically highlights the active menu link based on current page
 */

document.addEventListener('DOMContentLoaded', function() {
    const currentPage = window.location.pathname.split('/').pop() || 'dashboard.php';
    const menuLinks = document.querySelectorAll('.menu a, .navbar a');
    
    menuLinks.forEach(link => {
        const href = link.getAttribute('href');
        
        // Check if the link matches current page
        if (href === currentPage || 
            (currentPage === '' && href === 'index.html') ||
            (currentPage === 'index.php' && href === 'dashboard.php')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
});

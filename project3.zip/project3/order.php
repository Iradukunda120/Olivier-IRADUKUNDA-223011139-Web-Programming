<?php
session_start();

$page_title = "Order";

$userLoggedIn = isset($_SESSION['user_id']);
$guestWarning = '';
$showGuestPopup = false;

/* CREATE CART */
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$item = $_GET['item'] ?? "";

/* CART COUNT */
$cartCount = 0;
foreach ($_SESSION['cart'] as $c) {
    $cartCount += $c['qty'];
}

// Get fullname from session
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';
$initial = substr($fullname, 0, 1) . '.';

/* POPUP */
$showPopup = false;
$addedItems = [];

/* ADD TO CART */
if (isset($_POST['add_to_cart'])) {
    if ($userLoggedIn && isset($_POST['items'])) {
        foreach ($_POST['items'] as $key => $value) {
            $qty = $_POST['qty'][$key];
            $price = $_POST['price'][$key];

            if ($qty > 0) {
                $_SESSION['cart'][] = [
                    "name" => $value,
                    "qty" => $qty,
                    "price" => $price
                ];

                $addedItems[] = $value . " (Qty: " . $qty . ")";
            }
        }

        if (!empty($addedItems)) {
            $showPopup = true;
        }
    } else {
        $guestWarning = 'Please login or register before adding food to your cart.';
        $showGuestPopup = true;
    }
}

include "includes/header.php";
?>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f2e9;
            padding-top: 80px;
            color: #2b2b2b;
        }

        .cart-badge {
            background: #e74c3c;
            padding: 4px 10px;
            border-radius: 50%;
            font-weight: bold;
        }

        .container {
            width: min(1120px, 95%);
            margin: 24px auto;
        }

        .form-box {
            text-align: center;
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.08);
            padding: 32px 28px;
        }

        .services {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 24px;
            margin-top: 20px;
        }

        .card {
            background: #ffffff;
            padding: 26px 22px;
            text-align: center;
            border-radius: 20px;
            border: 1px solid rgba(0, 0, 0, 0.08);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.12);
        }

        .btn {
            padding: 12px 28px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }

        #popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.55);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .popup-box {
            background: white;
            padding: 28px;
            border-radius: 18px;
            width: min(420px, 90%);
            text-align: center;
        }

        input,
        textarea {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #d7d0c2;
            border-radius: 10px;
            outline: none;
            font-size: 1rem;
        }

        /* FOOTER STYLE */
        .footer {
            background: #8b6f47;
            color: white;
            padding: 30px;
            margin-top: 40px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }

        .footer a {
            color: #ddd;
            text-decoration: none;
            display: block;
            margin: 5px 0;
        }

        .footer a:hover {
            color: #fff;
        }
    </style>
</head>

<body>

    <!-- TAB BUTTONS -->
    <div class="container">
        <div class="form-box">
            <div style="margin:20px 0; text-align:center;">
            <a href="menu.php" style="padding:12px 25px;margin:5px;background:#28a745;color:white;border-radius:6px;text-decoration:none;">🍽️ Menu</a>
                <a href="room.php" style="padding:12px 25px;margin:5px;background:#222;color:white;border-radius:6px;text-decoration:none;">🏨 Rooms</a>
            </div>
        </div>
    </div>

    <!-- TITLE -->
    <div class="container">
        <div class="form-box">
            <h2><?php echo $item; ?> 🍽️</h2>
        </div>
    </div>

    <form method="POST" class="main-order-form">

        <div class="container">
            <div class="services">

                <?php
                function itemCard($name, $price, $i)
                {
                    echo "
    <div class='card'>
        <h3>$name</h3>
        <p>Price: $$price</p>

        <input type='checkbox' name='items[$i]' value='$name'><br><br>

        Quantity:<br>
        <input type='number' name='qty[$i]' value='0' min='0'>

        <input type='hidden' name='price[$i]' value='$price'>
    </div>
    ";
                }

                if ($item == "Lunch") {
                    itemCard("Grilled Chicken", 5, 0);
                    itemCard("Beef Steak", 7, 1);
                    itemCard("Fish & Chips", 6, 2);
                    itemCard("Vegetable Meal", 4, 3);
                } elseif ($item == "Rooms") {
                    itemCard("Standard Stay", 250, 0);
                    itemCard("Deluxe Suite", 400, 1);
                    itemCard("Executive Room", 600, 2);
                    itemCard("Presidential Suite", 1000, 3);
                } elseif ($item == "Seminar") {
                    itemCard("Conference Space", 2000, 0);
                    itemCard("Premium Hall", 5000, 1);
                }
                ?>

            </div>
        </div>

        <div style="text-align:center; margin:30px;">
            <button type="submit" name="add_to_cart" class="btn">🛒 Add to Cart</button>
        </div>

    </form>

    <!-- POPUP -->
    <?php if ($showPopup): ?>
        <div id="popup">
            <div class="popup-box">
                <h2>✅ Added to Cart</h2>

                <ul>
                    <?php foreach ($addedItems as $a): ?>
                        <li><?php echo $a; ?></li>
                    <?php endforeach; ?>
                </ul>

                <hr>

                <h3>📋 Booking Details</h3>

                <form action="cart.php" method="POST">
                    📅 Date:<br>
                    <input type="date" name="date" required><br>

                    👥 Number of People:<br>
                    <input type="number" name="people" min="1" required><br>

                    📝 Notes:<br>
                    <textarea name="note"></textarea>

                    <br><br>
                    <button type="submit" class="btn">Proceed to Checkout</button>
                </form>

                <br>
                <button onclick="closePopup()" class="btn">➕ Add More</button>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($showGuestPopup): ?>
        <div id="guestPopup" style="display:flex; position:fixed; top:0; left:0; width:100%; height:100%; background: rgba(0,0,0,0.55); justify-content:center; align-items:center; z-index:999;">
            <div class="popup-box">
                <h2>🔒 Login Required</h2>
                <p><?php echo htmlspecialchars($guestWarning); ?></p>
                <p>Please <a href="login.php">Login</a> or <a href="register.php">Register</a> to continue.</p>
                <button type="button" class="btn" onclick="closeGuestPopup()">Close</button>
            </div>
        </div>
    <?php endif; ?>

    <script>
        function closeGuestPopup() {
            const popup = document.getElementById('guestPopup');
            if (popup) popup.style.display = 'none';
        }

        const userLoggedIn = <?php echo $userLoggedIn ? 'true' : 'false'; ?>;
        const mainOrderForm = document.querySelector('form.main-order-form');

        if (mainOrderForm && !userLoggedIn) {
            mainOrderForm.addEventListener('submit', function (e) {
                e.preventDefault();
                const popup = document.getElementById('guestPopup');
                if (popup) popup.style.display = 'flex';
            });
        }
    </script>

<?php include "includes/footer.php"; ?>
<?php
/**
 * MO Hotel System - Best Practices & Utilities
 * This file contains helper functions and best practices
 */

// ==================== SECURITY BEST PRACTICES ====================

/**
 * Validate email
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (10-15 digits)
 */
function isValidPhone($phone) {
    return preg_match('/^[0-9]{10,15}$/', preg_replace('/\D/', '', $phone));
}

/**
 * Hash password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate secure token
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Sanitize HTML output
 */
function escapeHtml($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// ==================== VALIDATION FUNCTIONS ====================

/**
 * Validate booking date (must be future date)
 */
function isValidBookingDate($date) {
    $booking_date = new DateTime($date);
    $today = new DateTime('today');
    return $booking_date > $today;
}

/**
 * Validate price format
 */
function isValidPrice($price) {
    return is_numeric($price) && $price > 0;
}

/**
 * Validate quantity
 */
function isValidQuantity($qty) {
    return is_numeric($qty) && $qty > 0 && $qty <= 100;
}

// ==================== DATABASE UTILITIES ====================

/**
 * Check if email exists
 */
function emailExists($email) {
    global $conn;
    $query = "SELECT id FROM users WHERE email = ?";
    $result = executeQuery($query, [$email]);
    return $result['success'] && $result['result']->num_rows > 0;
}

/**
 * Get user by ID
 */
function getUserById($user_id) {
    global $conn;
    $query = "SELECT * FROM users WHERE id = ?";
    $result = executeQuery($query, [$user_id]);
    return $result['result']->fetch_assoc();
}

/**
 * Get booking by ID
 */
function getBookingById($booking_id) {
    global $conn;
    $query = "SELECT * FROM bookings WHERE id = ?";
    $result = executeQuery($query, [$booking_id]);
    return $result['result']->fetch_assoc();
}

/**
 * Update booking status
 */
function updateBookingStatus($booking_id, $status) {
    global $conn;
    $allowed_statuses = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];
    
    if (!in_array($status, $allowed_statuses)) {
        return false;
    }
    
    $query = "UPDATE bookings SET status = ?, updated_at = NOW() WHERE id = ?";
    $result = executeQuery($query, [$status, $booking_id]);
    return $result['success'];
}

// ==================== REPORTING & ANALYTICS ====================

/**
 * Get user statistics
 */
function getUserStats($user_id) {
    global $conn;
    $query = "SELECT 
                COUNT(*) as total_bookings,
                COUNT(CASE WHEN status='Completed' THEN 1 END) as completed,
                COUNT(CASE WHEN status='Cancelled' THEN 1 END) as cancelled,
                SUM(total_price) as total_spent
              FROM bookings WHERE user_id = ?";
    
    $result = executeQuery($query, [$user_id]);
    return $result['result']->fetch_assoc();
}

/**
 * Get revenue report
 */
function getRevenueReport($start_date, $end_date) {
    global $conn;
    $query = "SELECT 
                DATE(created_at) as date,
                COUNT(*) as bookings,
                SUM(total_price) as revenue
              FROM bookings 
              WHERE booking_date BETWEEN ? AND ? AND status='Completed'
              GROUP BY DATE(created_at)
              ORDER BY date DESC";
    
    $result = executeQuery($query, [$start_date, $end_date]);
    return $result['result'];
}

/**
 * Get popular items
 */
function getPopularItems($limit = 10) {
    global $conn;
    $query = "SELECT 
                item_name,
                COUNT(*) as bookings,
                SUM(quantity) as total_qty,
                SUM(total_price) as revenue
              FROM bookings
              GROUP BY item_name
              ORDER BY revenue DESC
              LIMIT ?";
    
    $result = executeQuery($query, [$limit]);
    return $result['result'];
}

// ==================== NOTIFICATION HELPERS ====================

/**
 * Create notification for user
 */
function createNotification($user_id, $type, $title, $message) {
    global $conn;
    $query = "INSERT INTO notifications (user_id, type, title, message)
              VALUES (?, ?, ?, ?)";
    
    return executeQuery($query, [$user_id, $type, $title, $message]);
}

/**
 * Get unread notifications
 */
function getUnreadNotifications($user_id) {
    global $conn;
    $query = "SELECT * FROM notifications 
              WHERE user_id = ? AND is_read = 0
              ORDER BY created_at DESC";
    
    $result = executeQuery($query, [$user_id]);
    return $result['result'];
}

// ==================== FILE UPLOAD UTILITIES ====================

/**
 * Upload image file
 */
function uploadImage($file, $destination) {
    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'png' => 'image/png'];
    $filename = basename($file['name']);
    $filetype = $file['type'];
    $filesize = $file['size'];
    
    // Check file type
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    if (!array_key_exists($ext, $allowed)) {
        return ['success' => false, 'error' => 'File type not allowed'];
    }
    
    // Check file size (max 5MB)
    if ($filesize > 5 * 1024 * 1024) {
        return ['success' => false, 'error' => 'File size exceeds 5MB'];
    }
    
    // Generate unique filename
    $new_filename = uniqid() . '.' . $ext;
    $filepath = $destination . $new_filename;
    
    // Move file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => true, 'filename' => $new_filename];
    } else {
        return ['success' => false, 'error' => 'Failed to upload file'];
    }
}

// ==================== MAINTENANCE FUNCTIONS ====================

/**
 * Cleanup old sessions (delete older than 30 days)
 */
function cleanupSessions() {
    global $conn;
    // Session cleanup logic
    // Usually handled by PHP, but you can add custom logic here
}

/**
 * Archive old bookings (mark as archived after 6 months)
 */
function archiveOldBookings() {
    global $conn;
    $query = "UPDATE bookings 
              SET status = 'Archived' 
              WHERE status = 'Completed' 
              AND DATE_ADD(booking_date, INTERVAL 6 MONTH) < NOW()";
    
    return executeQuery($query, []);
}

/**
 * Generate backup
 */
function backupDatabase() {
    // Implementation for database backup
    // Use mysqldump or other tools
}

// ==================== LOGGING ====================

/**
 * Log activity
 */
function logActivity($user_id, $action, $details = '') {
    global $conn;
    $query = "INSERT INTO activity_log (user_id, action, details, ip_address, created_at)
              VALUES (?, ?, ?, ?, NOW())";
    
    $ip = $_SERVER['REMOTE_ADDR'];
    return executeQuery($query, [$user_id, $action, $details, $ip]);
}

/**
 * Log error
 */
function logError($error_message, $file = '', $line = '') {
    $log_file = 'logs/errors.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] Error: $error_message | File: $file | Line: $line\n";
    
    if (!is_dir('logs')) {
        mkdir('logs');
    }
    
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

// ==================== API RESPONSE HELPERS ====================

/**
 * Return JSON response
 */
function jsonResponse($success, $message, $data = null) {
    header('Content-Type: application/json');
    return json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
}

/**
 * Pagination helper
 */
function paginate($query, $page = 1, $per_page = 10) {
    global $conn;
    
    $offset = ($page - 1) * $per_page;
    $paginated_query = $query . " LIMIT " . $offset . ", " . $per_page;
    
    $result = $conn->query($paginated_query);
    $total = $conn->query("SELECT COUNT(*) as count FROM (" . $query . ") as tmp")->fetch_assoc()['count'];
    
    return [
        'data' => $result,
        'total' => $total,
        'pages' => ceil($total / $per_page),
        'current_page' => $page,
        'per_page' => $per_page
    ];
}

// ==================== EMAIL TEMPLATE HELPERS ====================

/**
 * Get email template
 */
function getEmailTemplate($template_name) {
    $templates = [
        'welcome' => 'emails/welcome.html',
        'booking_confirmation' => 'emails/booking_confirmation.html',
        'payment_confirmation' => 'emails/payment_confirmation.html',
        'invoice' => 'emails/invoice.html',
        'cancellation' => 'emails/cancellation.html'
    ];
    
    $file = $templates[$template_name] ?? null;
    return $file && file_exists($file) ? file_get_contents($file) : null;
}

?>

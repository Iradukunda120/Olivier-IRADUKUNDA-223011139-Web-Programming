<?php
// Email Notification System for MO Hotel

class EmailNotification {
    private $to;
    private $subject;
    private $message;
    private $headers;
    
    public function __construct() {
        $this->headers = "MIME-Version: 1.0" . "\r\n";
        $this->headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $this->headers .= "From: noreply@nehotel.com" . "\r\n";
    }
    
    /**
     * Send account creation notification email
     */
    public function sendAccountCreationNotification($user_email, $fullname) {
        $this->to = $user_email;
        $this->subject = "Your MO Hotel account has been created";

        $this->message = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; background: #f5f5f5; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 40px auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 30px rgba(0,0,0,0.08); }
                .header { background: #8b6f47; color: white; padding: 20px; border-radius: 10px 10px 0 0; text-align: center; }
                .content { padding: 20px; color: #333; }
                .content h2 { color: #8b6f47; }
                .footer { background: #f3f2ef; padding: 15px; text-align: center; color: #666; font-size: 13px; border-radius: 0 0 10px 10px; }
                .button { display: inline-block; margin-top: 20px; padding: 12px 24px; background: #8b6f47; color: white; text-decoration: none; border-radius: 6px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>Welcome to MO Hotel!</h1>
                </div>
                <div class='content'>
                    <h2>Account Created Successfully</h2>
                    <p>Hi <strong>" . htmlspecialchars($fullname) . "</strong>,</p>
                    <p>Your MO Hotel account has been created successfully.</p>
                    <p>You're now ready to book rooms, order food, and enjoy our services.</p>
                    <p>If you need help, feel free to contact us at <a href='mailto:info@nehotel.com'>info@nehotel.com</a>.</p>
                    <a href='https://yourhotel.com/login' class='button'>Log In to Your Account</a>
                </div>
                <div class='footer'>
                    <p>© " . date('Y') . " MO Hotel. All Rights Reserved.</p>
                </div>
            </div>
        </body>
        </html>";

        return $this->send();
    }
    
    /**
     * Send generic email
     */
    private function send() {
        // Check if mail() function is available
        if (!function_exists('mail')) {
            error_log("Mail function not available. Email data: " . $this->subject);
            return false;
        }
        
        return mail($this->to, $this->subject, $this->message, $this->headers);
    }
    
    /**
     * Alternative: Log emails to database for testing
     */
    public static function logEmail($to, $subject, $message) {
        global $conn;
        $log_query = "INSERT INTO email_logs (to_email, subject, message, sent_at) VALUES (?, ?, ?, NOW())";
        return executeQuery($log_query, [$to, $subject, $message]);
    }
}

?>

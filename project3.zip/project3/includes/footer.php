</div><!-- Close main-content -->

<!-- FOOTER -->
<div class="footer">
    <div class="footer-container">
        <div>
            <h3>MO Hotel</h3>
            <p>Your comfort, our priority.</p>
            <p>⭐ Rated 4.8/5</p>
        </div>

        <div>
            <h4>Quick Links</h4>
            <a href="dashboard.php">Home</a>
            <a href="about.php">About Us</a>
            <a href="menu.php">Menu</a>
            <a href="order.php">Order Food</a>
            <a href="gallery.php">Gallery</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div>
            <h4>Contact Info</h4>
            <p>📧 mohotel@gmail.com</p>
            <p>📞 0792588858</p>
            <p>📍 Kigali, Rwanda</p>
            <p>🕐 24/7 Available</p>
        </div>

        <div>
            <h4>Follow Us</h4>
            <a href="https://x.com/ntongesten" target="_blank">𝕏 Twitter</a>
            <a href="https://www.facebook.com/erickseniz" target="_blank">📘 Facebook</a>
            <a href="https://wa.me/250780581260" target="_blank">📱 WhatsApp</a>
        </div>
    </div>

    <div class="footer-bottom">
        © <?php echo date("Y"); ?> MO Hotel. All Rights Reserved.
    </div>
</div>

<script src="js/active-nav.js"></script>
</body>
</html>
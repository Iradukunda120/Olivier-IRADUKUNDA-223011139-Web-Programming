<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current page name for active class
$current_page = basename($_SERVER['PHP_SELF']);

// Map page files to menu links for active highlighting
$page_map = [
    'dashboard.php' => 'dashboard.php',
    'index.html' => 'dashboard.php',
    'about.php' => 'about.php',
    'about.html' => 'about.php',
    'menu.php' => 'menu.php',
    'menu.html' => 'menu.php',
    'order.php' => 'order.php',
    'order_form.php' => 'order.php',
    'profile.php' => 'profile.php',
    'gallery.php' => 'gallery.php',
    'contact.php' => 'contact.php',
    'contact.html' => 'contact.php'
];

// Get the mapped page for active state
$active_page = $page_map[$current_page] ?? $current_page;

$cartCount = 0;
if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $cartItem) {
        $cartCount += isset($cartItem['qty']) ? (int)$cartItem['qty'] : 1;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MO Hotel | <?php echo $page_title ?? 'Home'; ?></title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .user-dropdown {
            position: relative;
            display: inline-block;
            text-align: left;
        }
        .user-dropdown .user-link {
            color: white;
            text-decoration: none;
            padding: 8px 14px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border-radius: 24px;
            background: rgba(255, 255, 255, 0.1);
            transition: background 0.25s ease;
        }
        .user-dropdown .user-link:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        .user-dropdown .user-link::after {
            content: '▼';
            font-size: 0.7rem;
            margin-left: 4px;
            opacity: 0.8;
        }
        .user-dropdown .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: calc(100% + 10px);
            background: white;
            border: 1px solid rgba(0,0,0,0.08);
            border-radius: 12px;
            min-width: 170px;
            box-shadow: 0 18px 40px rgba(0,0,0,0.12);
            z-index: 10;
        }
        .user-dropdown:hover .dropdown-menu {
            display: block;
        }
        .user-dropdown .dropdown-menu a {
            display: block;
            padding: 10px 16px;
            color: #333;
            text-decoration: none;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        .user-dropdown .dropdown-menu a:last-child {
            border-bottom: none;
        }
        .user-dropdown .dropdown-menu a:hover {
            background: #f7f7f7;
        }
    </style>
</head>
<body>

<!-- FIXED NAVBAR -->
<div class="navbar">
    <div class="logo">
        <h2>MO Hotel</h2>
    </div>
    
    <div class="menu">
        <a href="dashboard.php" class="<?php echo ($active_page == 'dashboard.php' || $current_page == 'index.html') ? 'active' : ''; ?>">Home</a>
        <a href="about.php" class="<?php echo ($active_page == 'about.php') ? 'active' : ''; ?>">About Us</a>
        <a href="menu.php" class="<?php echo ($active_page == 'menu.php') ? 'active' : ''; ?>">Menu</a>
        <a href="order.php" class="<?php echo ($active_page == 'order.php') ? 'active' : ''; ?>">Order</a>
        <?php if (isset($_SESSION['email'])): ?>
            <a href="profile.php" class="<?php echo ($active_page == 'profile.php') ? 'active' : ''; ?>">Profile</a>
        <?php endif; ?>
        <a href="gallery.php" class="<?php echo ($active_page == 'gallery.php') ? 'active' : ''; ?>">Gallery</a>
        <a href="contact.php" class="<?php echo ($active_page == 'contact.php') ? 'active' : ''; ?>">Contact Us</a>
    </div>
    
    <div class="auth">
        <a href="cart.php" class="cart-link">🛒 Cart (<?php echo $cartCount; ?>)</a>
        <?php if(isset($_SESSION['email'])):
            $user = isset($_SESSION['fullname']) && trim($_SESSION['fullname']) !== '' ? explode(' ', trim($_SESSION['fullname']))[0] : explode('@', $_SESSION['email'])[0];
        ?>
            <div class="user-dropdown">
                <a class="user-link" href="profile.php">👋 Hello, <?php echo htmlspecialchars($user); ?></a>
                <div class="dropdown-menu">
                    <a href="profile.php">My Profile</a>
                    <a href="invoices.php">My Invoices</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Sign Up</a>
        <?php endif; ?>
    </div>
</div>

<div class="main-content">
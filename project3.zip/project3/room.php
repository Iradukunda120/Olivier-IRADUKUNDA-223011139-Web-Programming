<?php
session_start();

$items = [
    ["img" => "luxuryroom.jpeg", "title" => "Luxury Room", "price" => 400],
    ["img" => "regularroom.jpeg", "title" => "Standard Room", "price" => 250],
    ["img" => "vvip.jpeg", "title" => "VVIP Room", "price" => 600],
    ["img" => "vvip1.jpeg", "title" => "Presidential Suite", "price" => 1000],

    ["img" => "conference.jpeg", "title" => "Conference Hall", "price" => 2000],
    ["img" => "conference1.jpeg", "title" => "Premium Seminar Hall", "price" => 5000]
];
?>

<!DOCTYPE html>
<html>

<head>
    <title>Rooms & Seminar Hall</title>

    <style>
        body {
            margin: 0;
            font-family: Arial;
            background: #eceded;
        }

        .header {
            background: #222;
            color: white;
            padding: 15px;
            display: flex;
            justify-content: space-between;
        }

        .header a {
            background: #79a9e0;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 5px;
        }

        .container {
            width: 90%;
            margin: 20px auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .price {
            font-weight: bold;
            margin: 10px;
        }

        .btn {
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .badge {
            background: orange;
            color: white;
            padding: 4px 8px;
            border-radius: 5px;
            font-size: 12px;
        }
    </style>
</head>

<body>

    <div class="header">
        <h2>Rooms & Seminar Hall</h2>
        <a href="dashboard.php">🏠 Back Home</a>
    </div>

    <div class="container">

        <?php foreach ($items as $i => $item): ?>

            <div class="card">
                <img src="images/gallery/<?php echo $item['img']; ?>">

                <h3><?php echo $item['title']; ?></h3>

                <div class="price">$<?php echo $item['price']; ?></div>

                <?php if ($item['price'] >= 2000): ?>
                    <div class="badge">Seminar</div>
                <?php else: ?>
                    <div class="badge">Room</div>
                <?php endif; ?>

                <br>

                <!-- ✅ Direct booking button -->
                <form method="POST" action="booking.php">

                    <input type="hidden" name="items[<?php echo $i; ?>]" value="<?php echo $item['title']; ?>">
                    <input type="hidden" name="qty[<?php echo $i; ?>]" value="1">
                    <input type="hidden" name="price[<?php echo $i; ?>]" value="<?php echo $item['price']; ?>">
                    <input type="hidden" name="add_to_cart" value="1">

                    <button type="submit" class="btn">
                        Book Now / Reserve
                    </button>

                </form>

                <br>

            </div>

        <?php endforeach; ?>

    </div>

</body>

</html>
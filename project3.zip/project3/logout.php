<?php
session_start();

// Check if user confirmed the logout
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    session_destroy();
    header("Location: login.php");
    exit();
}

// If not confirmed, show confirmation page
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logout Confirmation | MO Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: Arial;
            background: #f5ede3;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .confirmation-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        .confirmation-box h2 {
            color: #8b6f47;
            margin-top: 0;
        }
        .confirmation-box p {
            color: #333;
            font-size: 16px;
            margin: 20px 0;
        }
        .button-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        .btn-logout {
            padding: 12px 30px;
            background: #8b6f47;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
        }
        .btn-logout:hover {
            background: #6d5435;
        }
        .btn-cancel {
            padding: 12px 30px;
            background: #999;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
        }
        .btn-cancel:hover {
            background: #777;
        }
    </style>
</head>
<body>
    <div class="confirmation-box">
        <h2>🚪 Logout Confirmation</h2>
        <p>Are you sure you want to logout?</p>
        <div class="button-group">
            <a href="logout.php?confirm=yes" class="btn-logout">Yes, Logout</a>
            <a href="dashboard.php" class="btn-cancel">No, Stay</a>
        </div>
    </div>
</body>
</html>

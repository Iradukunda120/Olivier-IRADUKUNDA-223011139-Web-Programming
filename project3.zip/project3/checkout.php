<?php
session_start();
include "connect.php";
include "payment.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$booking_id = isset($_GET['booking_id']) ? (int)$_GET['booking_id'] : 0;

if ($booking_id == 0) {
    header("Location: profile.php");
    exit();
}

// Get booking details
$query = "SELECT b.*, u.email FROM bookings b
          JOIN users u ON b.user_id = u.id
          WHERE b.id = ? AND b.user_id = ?";

$result = executeQuery($query, [$booking_id, $user_id]);

if (!$result['success'] || $result['result']->num_rows == 0) {
    header("Location: profile.php");
    exit();
}

$booking = $result['result']->fetch_assoc();

// Check if already paid
if ($booking['status'] == 'Confirmed' || $booking['status'] == 'Completed') {
    header("Location: invoices.php");
    exit();
}

// Process payment
$payment_status = null;
if (isset($_POST['process_payment'])) {
    $payment_result = PaymentProcessor::processPayment($booking_id, $booking['total_price'], 'stripe');
    $payment_status = $payment_result;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Payment | MO Hotel</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #f5ede3 0%, #e8dcc8 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            max-width: 1000px;
            width: 100%;
        }
        .order-summary {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            height: fit-content;
        }
        .payment-form {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #8b6f47;
            margin-bottom: 25px;
            border-bottom: 2px solid #8b6f47;
            padding-bottom: 10px;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        .summary-item:last-of-type {
            border-bottom: none;
        }
        .summary-item label {
            color: #666;
        }
        .summary-item strong {
            color: #8b6f47;
        }
        .summary-total {
            display: flex;
            justify-content: space-between;
            padding: 15px 0;
            margin-top: 15px;
            border-top: 2px solid #8b6f47;
            font-size: 18px;
            font-weight: bold;
            color: #8b6f47;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }
        input, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #8b6f47;
            box-shadow: 0 0 0 3px rgba(139, 111, 71, 0.1);
        }
        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #8b6f47 0%, #a68860 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: transform 0.2s;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(30, 58, 138, 0.3);
        }
        .security-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            background: #f0f9ff;
            border-radius: 5px;
            margin-top: 15px;
            font-size: 12px;
            color: #666;
        }
        .security-info strong {
            color: #28a745;
        }
        
        .success-message {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }
        .success-message.show {
            display: block;
        }
        .error-message {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: none;
        }
        .error-message.show {
            display: block;
        }

        @media (max-width: 768px) {
            .container {
                grid-template-columns: 1fr;
            }
        }

        .nav-back {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
        }
    </style>
</head>
<body>

    <a href="profile.php" class="nav-back">← Back</a>

    <div class="container">
        
        <!-- Order Summary -->
        <div class="order-summary">
            <h2>📋 Order Summary</h2>
            
            <div class="summary-item">
                <label>Item:</label>
                <strong><?php echo htmlspecialchars($booking['item_name']); ?></strong>
            </div>
            
            <div class="summary-item">
                <label>Quantity:</label>
                <strong><?php echo $booking['quantity']; ?></strong>
            </div>
            
            <div class="summary-item">
                <label>Booking Date:</label>
                <strong><?php echo date('F d, Y', strtotime($booking['booking_date'])); ?></strong>
            </div>
            
            <div class="summary-item">
                <label>Status:</label>
                <strong style="color: #ffc107;">⏳ <?php echo $booking['status']; ?></strong>
            </div>
            
            <?php if ($booking['notes']): ?>
            <div class="summary-item">
                <label>Notes:</label>
                <strong><?php echo htmlspecialchars($booking['notes']); ?></strong>
            </div>
            <?php endif; ?>
            
            <div class="summary-total">
                <span>Total Amount:</span>
                <span>$<?php echo number_format($booking['total_price'], 2); ?></span>
            </div>
        </div>

        <!-- Payment Form -->
        <div class="payment-form">
            <h2>💳 Payment Details</h2>

            <?php if ($payment_status): ?>
                <?php if ($payment_status['success']): ?>
                    <div class="success-message show">
                        ✅ Payment processed successfully! Redirecting...
                        <meta http-equiv="refresh" content="3;url=invoices.php">
                    </div>
                <?php else: ?>
                    <div class="error-message show">
                        ❌ Payment failed: <?php echo $payment_status['message']; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="booking_id" value="<?php echo $booking_id; ?>">
                <input type="hidden" name="amount" value="<?php echo htmlspecialchars($booking['total_price']); ?>">

                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" value="<?php echo htmlspecialchars($_SESSION['fullname']); ?>" readonly style="background:#f0f0f0; cursor:not-allowed;">
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" value="<?php echo htmlspecialchars($booking['email']); ?>" readonly style="background:#f0f0f0; cursor:not-allowed;">
                </div>

                <div class="form-group">
                    <label>Payment Method</label>
                    <select name="payment_method" required>
                        <option value="">-- Select Payment Method --</option>
                        <option value="credit_card">💳 Credit Card</option>
                        <option value="debit_card">💳 Debit Card</option>
                        <option value="paypal">🅿️ PayPal</option>
                        <option value="bank_transfer">🏦 Bank Transfer</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Card Number</label>
                    <input type="text" name="card_number" placeholder="1234 5678 9012 3456" pattern="[0-9\s]{13,23}" required>
                </div>

                <div class="row">
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <input type="text" placeholder="MM/YY" pattern="[0-9]{2}/[0-9]{2}" required>
                    </div>
                    <div class="form-group">
                        <label>CVV</label>
                        <input type="text" placeholder="123" pattern="[0-9]{3,4}" maxlength="4" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Cardholder Name</label>
                    <input type="text" name="cardholder_name" placeholder="Enter name on card" required>
                </div>

                <div style="display:flex; gap:20px; font-size:13px; color:#666; align-items:center;">
                    <input type="checkbox" name="agree_terms" required>
                    <label style="margin:0;">I agree to the terms and conditions</label>
                </div>

                <button type="submit" name="process_payment" class="submit-btn">
                    💳 Pay $<?php echo number_format($booking['total_price'], 2); ?>
                </button>

                <div class="security-info">
                    🔒 <strong>Secure Payment</strong> - Your payment is encrypted and secure
                </div>
            </form>
        </div>

    </div>

</body>
</html>

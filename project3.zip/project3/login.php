<?php
include "session_config.php";
include "connect.php";

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$errors = [];
$email_value = '';

if (isset($_POST['login'])) {
    $email_value = isset($_POST['email']) ? strtolower(trim($_POST['email'])) : '';
    $email = sanitize($email_value);
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($email) || empty($password)) {
        $errors[] = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if (empty($errors)) {
        $query = "SELECT id, fullname, email, password FROM users WHERE email = ?";
        $result = executeQuery($query, [$email]);

        if ($result['success'] && $result['result'] && $result['result']->num_rows === 1) {
            $user = $result['result']->fetch_assoc();
            $storedPassword = $user['password'];

            if (password_verify($password, $storedPassword)) {
                $loginOk = true;
            } elseif (md5($password) === $storedPassword) {
                $loginOk = true;
                $rehash = password_hash($password, PASSWORD_DEFAULT);
                $updateQuery = "UPDATE users SET password = ? WHERE id = ?";
                executeQuery($updateQuery, [$rehash, $user['id']]);
            } else {
                $loginOk = false;
            }

            if (!empty($loginOk)) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['fullname'] = $user['fullname'];
                header("Location: dashboard.php");
                exit();
            }
        }

        $errors[] = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>MO Hotel | Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, sans-serif;
            background: linear-gradient(135deg, #f5ede3 0%, #e8dcc8 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .auth-page {
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
        }

        .auth-panel {
            display: flex;
            flex-wrap: wrap;
            background: rgba(255, 255, 255, 0.96);
            border-radius: 2.5rem;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            overflow: hidden;
        }

        .auth-side {
            flex: 1.1;
            background: linear-gradient(125deg, #0b2b26 0%, #1a4a42 100%);
            padding: 3rem 2.5rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            color: white;
            position: relative;
        }

        .auth-side::before {
            content: '';
            position: absolute;
            top: -30%;
            right: -20%;
            width: 280px;
            height: 280px;
            background: radial-gradient(circle, rgba(255, 215, 150, 0.18) 0%, rgba(255, 215, 150, 0) 70%);
            border-radius: 50%;
            pointer-events: none;
        }

        .brand-mark {
            font-size: 2.2rem;
            font-weight: 700;
            background: rgba(255, 255, 240, 0.2);
            display: inline-block;
            width: fit-content;
            padding: 0.4rem 1.2rem;
            border-radius: 60px;
            backdrop-filter: blur(4px);
            margin-bottom: 2rem;
            border: 1px solid rgba(255, 255, 210, 0.3);
        }

        .side-top h3 {
            font-size: 2rem;
            font-weight: 600;
            margin: 1rem 0 0.75rem 0;
        }

        .side-top p {
            font-size: 1rem;
            opacity: 0.85;
            max-width: 85%;
            line-height: 1.5;
        }

        .side-features {
            margin-top: 3rem;
            display: flex;
            flex-direction: column;
            gap: 1.2rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            background: rgba(255, 255, 245, 0.08);
            padding: 0.75rem 1rem;
            border-radius: 60px;
            width: fit-content;
        }

        .feature-item span {
            background: #e9c46a;
            color: #1e3b36;
            width: 26px;
            height: 26px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .auth-card {
            flex: 1.2;
            padding: 3rem 2.8rem;
            background: #ffffff;
        }

        .auth-card h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #1e2f2c;
            margin-bottom: 0.6rem;
        }

        .auth-card>p {
            color: #5f6c6a;
            margin-bottom: 1.8rem;
            font-size: 0.9rem;
            border-left: 3px solid #d4af7a;
            padding-left: 0.9rem;
        }

        .error {
            background: #fff5f5;
            border-left: 4px solid #e07c7c;
            padding: 0.9rem 1.2rem;
            border-radius: 1rem;
            margin-bottom: 1.8rem;
            color: #b13e3e;
            font-size: 0.85rem;
        }

        .error p {
            margin: 0.2rem 0;
        }

        .input-group {
            position: relative;
            margin-bottom: 1.8rem;
        }

        .auth-input {
            width: 100%;
            padding: 1rem 1rem 0.5rem 1rem;
            font-size: 1rem;
            border: 1.5px solid #e2e8f0;
            background: #ffffff;
            border-radius: 1rem;
            outline: none;
            transition: all 0.2s ease;
            font-family: inherit;
            color: #1a2e2a;
        }

        .auth-input:focus {
            border-color: #c9a96e;
            box-shadow: 0 0 0 3px rgba(201, 169, 110, 0.2);
        }

        .auth-input.error-field {
            border-color: #e07c7c;
            background-color: #fffafa;
        }

        .input-label {
            position: absolute;
            left: 1rem;
            top: 0.9rem;
            background-color: transparent;
            padding: 0 0.2rem;
            color: #7e8b88;
            font-size: 1rem;
            transition: 0.2s ease;
            pointer-events: none;
        }

        .auth-input:focus~.input-label,
        .auth-input:not(:placeholder-shown)~.input-label {
            top: -0.55rem;
            left: 0.8rem;
            font-size: 0.75rem;
            background: white;
            color: #b98f52;
            font-weight: 500;
            padding: 0 0.3rem;
        }

        .auth-input:placeholder-shown~.input-label {
            top: 0.9rem;
            font-size: 1rem;
        }

        .field-error {
            font-size: 0.7rem;
            color: #d14545;
            margin-top: 0.3rem;
            margin-left: 0.5rem;
            display: none;
        }

        .input-group.has-error .field-error {
            display: block;
        }

        .input-group.has-error .auth-input {
            border-color: #e07c7c;
        }

        .auth-button {
            width: 100%;
            background: #1e4a44;
            color: white;
            font-size: 1rem;
            font-weight: 600;
            padding: 0.9rem;
            border: none;
            border-radius: 2rem;
            cursor: pointer;
            transition: all 0.25s;
            margin-top: 0.6rem;
        }

        .auth-button:hover {
            background: #0e3a34;
            transform: translateY(-2px);
            box-shadow: 0 12px 20px -12px rgba(0, 0, 0, 0.25);
        }

        .auth-button.loading {
            background: #8ba19e;
            cursor: wait;
            transform: none;
        }

        .auth-note {
            text-align: center;
            margin-top: 2rem;
            font-size: 0.85rem;
            color: #4a5b58;
        }

        .auth-note a {
            color: #b87c3a;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-note a:hover {
            text-decoration: underline;
        }

        @media (max-width: 900px) {
            body {
                padding: 1rem;
            }

            .auth-panel {
                flex-direction: column;
            }

            .auth-side {
                padding: 2rem 1.5rem;
                text-align: center;
            }

            .feature-item {
                width: 100%;
                justify-content: center;
            }

            .auth-card {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>

<body>
    <div class="auth-page">
        <div class="auth-panel">
            <div class="auth-side">
                <div class="side-top">
                    <div class="brand-mark">MO HOTEL</div>
                    <h3>Welcome to MO Hotel</h3>
                    <p>Secure login to manage room reservations, dining orders and your hotel profile.</p>
                </div>
                <div class="">
                    <div class=""><span></span>
                        <p></p>
                    </div>
                    <div class=""><span></span>
                        <p></p>
                    </div>
                    <div class=""><span></span>
                        <p></p>
                    </div>
                </div>
            </div>

            <div class="auth-card">
                <h2>Welcome Back</h2>
                <p>Login to your MO Hotel account and manage your bookings instantly.</p>

                <?php if (!empty($errors)): ?>
                    <div class="error">
                        <?php foreach ($errors as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form id="loginForm" method="POST" novalidate>
                    <div class="input-group" id="emailGroup">
                        <input class="auth-input" type="email" id="email" name="email" placeholder=" " value="<?php echo htmlspecialchars($email_value); ?>" required>
                        <label class="input-label">Email *</label>
                        <div class="field-error">Please enter a valid email address.</div>
                    </div>

                    <div class="input-group" id="passwordGroup">
                        <input class="auth-input" type="password" id="password" name="password" placeholder=" " required>
                        <label class="input-label">Password *</label>
                        <div class="field-error">Password is required.</div>
                    </div>

                    <button class="auth-button" type="submit" name="login" id="loginBtn">Login</button>
                </form>

                <div class="auth-note">
                    Don't have an account? <a href="register.php">Create one</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Client-side validation for better UX
        const form = document.getElementById('loginForm');
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const emailGroup = document.getElementById('emailGroup');
        const passwordGroup = document.getElementById('passwordGroup');
        const loginBtn = document.getElementById('loginBtn');

        function validateEmail() {
            const email = emailInput.value.trim();
            const isValid = email !== '' && /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/.test(email);
            if (!isValid && email !== '') {
                emailGroup.classList.add('has-error');
            } else if (email === '') {
                emailGroup.classList.add('has-error');
            } else {
                emailGroup.classList.remove('has-error');
            }
            return isValid && email !== '';
        }

        function validatePassword() {
            const pwd = passwordInput.value;
            const isValid = pwd.trim().length > 0;
            if (!isValid) {
                passwordGroup.classList.add('has-error');
            } else {
                passwordGroup.classList.remove('has-error');
            }
            return isValid;
        }

        emailInput.addEventListener('input', validateEmail);
        passwordInput.addEventListener('input', validatePassword);

        form.addEventListener('submit', function(e) {
            const isEmailValid = validateEmail();
            const isPasswordValid = validatePassword();

            if (!isEmailValid || !isPasswordValid) {
                e.preventDefault();
                alert('Please fill in all fields correctly.');
            }
        });

        // Set placeholder for floating labels
        document.querySelectorAll('.auth-input').forEach(inp => {
            if (!inp.hasAttribute('placeholder')) inp.setAttribute('placeholder', ' ');
        });
    </script>
</body>

</html>
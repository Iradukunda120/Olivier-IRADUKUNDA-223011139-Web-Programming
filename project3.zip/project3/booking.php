<?php
session_start();
include "connect.php";

function generateInvoice($booking_id, $user_id, $item_name, $total_price) {
    global $conn;
    
    // Generate unique invoice number
    $invoice_number = 'INV-' . date('Ymd') . '-' . str_pad($booking_id, 4, '0', STR_PAD_LEFT);
    
    // Calculate tax (18% tax)
    $tax_rate = 0.18;
    $tax_amount = $total_price * $tax_rate;
    $final_amount = $total_price + $tax_amount;
    
    // Insert invoice record
    $insert_query = "INSERT INTO invoices (booking_id, user_id, invoice_number, total_amount, tax_amount, status)
                     VALUES (?, ?, ?, ?, ?, ?)";
    
    $result = executeQuery($insert_query, [
        $booking_id,
        $user_id,
        $invoice_number,
        $final_amount,
        $tax_amount,
        'Generated'
    ]);
    
    return $result['success'] ? $invoice_number : false;
}

$userLoggedIn = isset($_SESSION['user_id']);

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$guestWarning = '';
$showLoginPopup = false;

if (isset($_POST['add_to_cart'])) {
    if ($userLoggedIn && isset($_POST['items'])) {
        foreach ($_POST['items'] as $key => $value) {
            $qty = isset($_POST['qty'][$key]) ? (int)$_POST['qty'][$key] : 1;
            $price = isset($_POST['price'][$key]) ? (float)$_POST['price'][$key] : 0;

            if ($qty > 0) {
                $_SESSION['cart'][] = [
                    'name' => $value,
                    'qty' => $qty,
                    'price' => $price
                ];
            }
        }

        header("Location: booking.php");
        exit();
    }

    $guestWarning = 'Please login or register before adding a booking to your cart.';
    $showLoginPopup = true;
}

// Get fullname from session
$fullname = isset($_SESSION['fullname']) ? explode(' ', $_SESSION['fullname'])[0] : 'Guest';

$user_id = $_SESSION['user_id'] ?? null;
$cart = $_SESSION['cart'] ?? [];

$showPopup = false;
$booking_ids = [];
$total_amount = 0;

if (isset($_POST['submit'])) {
    if (!$userLoggedIn) {
        $guestWarning = 'Please login or register before confirming a booking.';
        $showLoginPopup = true;
    } else {
        $fullname = sanitize($_POST['fullname']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $booking_date = date('Y-m-d');
        $check_in_date = sanitize($_POST['check_in_date']);
        $check_out_date = sanitize($_POST['check_out_date']);
        $adults = (int)($_POST['adults'] ?? 1);
        $children = (int)($_POST['children'] ?? 0);
        $number_of_people = max(1, $adults + $children);
        $room_preference = sanitize($_POST['room_preference'] ?? '');
        $smoking_preference = sanitize($_POST['smoking_preference'] ?? '');
        $bed_type = sanitize($_POST['bed_type'] ?? '');
        $arrival_time = sanitize($_POST['arrival_time'] ?? '');
        $payment_method = 'Credit Card';
        $cc_number = preg_replace('/\\D/', '', $_POST['cc_number'] ?? '');
        $card_last4 = $cc_number ? substr($cc_number, -4) : null;
        $cardholder_name = sanitize($_POST['cardholder_name'] ?? '');
        $cc_expiry = sanitize($_POST['cc_expiry'] ?? '');
        $cc_cvc = sanitize($_POST['cc_cvc'] ?? '');
        $guarantee_amount = max(0, (float)($_POST['guarantee_amount'] ?? 0));
        $cancellation_policy_ack = isset($_POST['cancellation_policy_ack']) ? 1 : 0;
        $notes = sanitize($_POST['notes'] ?? '');

        foreach ($cart as $c) {

        $item = sanitize($c['name']);
        $qty = (int)$c['qty'];
        $price = (float)$c['price'];
        $total_price = $qty * $price;
        $total_amount += $total_price;

        // Use prepared statement to insert booking
        $insert_query = "INSERT INTO bookings (user_id, booking_type, item_id, item_name, guest_fullname, contact_email, contact_phone, room_id, adults, children, room_preference, smoking_preference, bed_type, arrival_time, payment_method, card_last4, guarantee_amount, cancellation_policy_ack, quantity, booking_date, check_in_date, check_out_date, number_of_people, total_price, status, notes)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $result = executeQuery($insert_query, [
            $user_id,
            'Hotel',
            0,
            $item,
            $fullname,
            $email,
            $phone,
            0,
            $adults,
            $children,
            $room_preference,
            $smoking_preference,
            $bed_type,
            $arrival_time,
            $payment_method,
            $card_last4,
            $guarantee_amount,
            $cancellation_policy_ack,
            $qty,
            $booking_date,
            $check_in_date,
            $check_out_date,
            $number_of_people,
            $total_price,
            'Pending',
            $notes
        ]);

        if ($result['success']) {
            $booking_ids[] = $conn->insert_id;
            
            // Generate invoice for this booking
            $invoice_number = generateInvoice($conn->insert_id, $user_id, $item, $total_price);
        }
        }
    }

    if (!empty($booking_ids)) {
        $showPopup = true;
    }
}

$page_title = "Hotel Booking";
include "includes/header.php";
?>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f2e9;
            padding-top: 80px;
            color: #2b2b2b;
        }

        .container {
            max-width: 800px;
            margin: 24px auto;
        }

        .form-box {
            background: #ffffff;
            border-radius: 24px;
            box-shadow: 0 24px 60px rgba(0, 0, 0, 0.08);
            padding: 32px 28px;
        }

        .services {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 24px;
            margin-top: 20px;
        }

        .card {
            background: #ffffff;
            padding: 26px 22px;
            text-align: center;
            border-radius: 20px;
            border: 1px solid rgba(0, 0, 0, 0.08);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.12);
        }

        .btn {
            padding: 12px 28px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 600;
        }

        #popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.55);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 999;
        }

        .popup-box {
            background: white;
            padding: 28px;
            border-radius: 18px;
            width: min(420px, 90%);
            text-align: center;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #d7d0c2;
            border-radius: 10px;
            outline: none;
            font-size: 1rem;
        }

        /* FOOTER STYLE */
        .footer {
            background: #8b6f47;
            color: white;
            padding: 30px;
            margin-top: 40px;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }

        .footer a {
            color: #ddd;
            text-decoration: none;
            display: block;
            margin: 5px 0;
        }

        .footer a:hover {
            color: #fff;
        }
    </style>

    <div class="container">

        <div class="form-box">

            <h2>🏨 Hotel Booking</h2>

            <!-- BOOKING SUMMARY -->
            <div class="summary" style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                <h3>Booking Summary</h3>
                <?php
                $total = 0;
                foreach ($cart as $item):
                    $item_total = ($item['qty'] ?? 1) * ($item['price'] ?? 0);
                    $total += $item_total;
                ?>
                    <div class="summary-item" style="display: flex; justify-content: space-between; padding: 8px; border-bottom: 1px solid #ddd;">
                        <span><?php echo htmlspecialchars($item['name'] ?? 'Unknown Item'); ?> x<?php echo $item['qty'] ?? 1; ?></span>
                        <span>$<?php echo number_format($item_total, 2); ?></span>
                    </div>
                <?php endforeach; ?>
                <div class="total" style="font-weight: bold; color: #8b6f47; font-size: 16px; padding: 10px 0; border-top: 2px solid #8b6f47; margin-top: 10px;">
                    Total: $<?php echo number_format($total, 2); ?>
                </div>
            </div>

            <!-- BOOKING FORM -->
            <form method="POST" class="booking-form">

                <input type="text" name="fullname" placeholder="Full Name" required value="<?php echo htmlspecialchars($_SESSION['fullname'] ?? ''); ?>">
                <input type="email" name="email" placeholder="Email" required value="<?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?>">
                <input type="tel" name="phone" placeholder="Phone" required>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px;">
                    <input type="date" name="check_in_date" required>
                    <input type="date" name="check_out_date" required>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px;">
                    <input type="number" name="adults" min="1" value="1" required placeholder="Adults">
                    <input type="number" name="children" min="0" value="0" placeholder="Children">
                </div>

                <select name="room_preference" required>
                    <option value="">Room preference</option>
                    <option value="Quiet room">Quiet room</option>
                    <option value="Near elevator">Near elevator</option>
                    <option value="High floor">High floor</option>
                    <option value="Low floor">Low floor</option>
                </select>

                <select name="smoking_preference" required>
                    <option value="">Smoking preference</option>
                    <option value="Non-smoking">Non-smoking</option>
                    <option value="Smoking">Smoking</option>
                </select>

                <select name="bed_type" required>
                    <option value="">Bed type</option>
                    <option value="Single">Single</option>
                    <option value="Double">Double</option>
                    <option value="Queen">Queen</option>
                    <option value="King">King</option>
                </select>

                <input type="time" name="arrival_time" required placeholder="Expected arrival time">
                <input type="text" name="cc_number" placeholder="Credit card number (optional)" maxlength="19">
                <input type="text" name="cardholder_name" placeholder="Cardholder name (optional)">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;">
                    <input type="text" name="cc_expiry" placeholder="Expiry MM/YY (optional)">
                    <input type="text" name="cc_cvc" placeholder="CVC (optional)">
                </div>
                <input type="number" name="guarantee_amount" min="0" step="0.01" value="0" placeholder="Guarantee amount (optional)">

                <textarea name="notes" placeholder="Special requests or notes (optional)" rows="4"></textarea>

                <label style="font-size: 14px; color: #555; margin: 10px 0 0; display: block;">
                    <input type="checkbox" name="cancellation_policy_ack" required>
                    I have read and agree to the cancellation policy.
                </label>

                <button type="submit" name="submit">✅ Book Now</button>

            </form>

        </div>

    </div>

    <!-- LOGIN REQUIRED POPUP -->
    <?php if ($showLoginPopup): ?>
        <div id="loginPopup" class="modal" style="display:flex;">
            <div class="modal-content">
                <h2>🔒 Login Required</h2>
                <p><?php echo htmlspecialchars($guestWarning); ?></p>
                <p>Please <a href="login.php">Login</a> or <a href="register.php">Register</a> to continue.</p>
                <button type="button" onclick="closeGuestPopup()" class="btn" style="background:#333; margin-top:16px;">Close</button>
            </div>
        </div>
    <?php endif; ?>

    <!-- SUCCESS POPUP -->
    <?php if ($showPopup): ?>

        <div class="modal" style="display: flex;">

            <div class="modal-content">

                <h2>✅ Booking Successful!</h2>

                <p>Your hotel booking has been placed successfully.</p>

                <p><strong>📅 Booking ID:</strong> #<?php echo implode(', #', $booking_ids); ?></p>
                <p><strong>💰 Total Amount:</strong> $<?php echo number_format($total_amount, 2); ?></p>
                <p><strong>📊 Status:</strong> Pending Payment</p>

                <h3>Booked Items:</h3>
                <ul style="text-align: left; padding-left: 20px;">
                    <?php foreach ($cart as $c): ?>
                        <li><?php echo htmlspecialchars($c['name']); ?> (Qty: <?php echo $c['qty']; ?>) - $<?php echo number_format($c['qty'] * $c['price'], 2); ?></li>
                    <?php endforeach; ?>
                </ul>

                <p style="color: #666; font-size: 13px; margin-top: 15px;">
                    📧 A confirmation email has been sent to <strong><?php echo htmlspecialchars($email); ?></strong>
                </p>

                <a href="profile.php">📋 View My Bookings</a>
                <a href="dashboard.php" style="margin-left: 10px;">🏠 Back to Home</a>

            </div>

        </div>

    <?php unset($_SESSION['cart']); endif; ?>

    <script>
        const guestBooking = <?php echo $userLoggedIn ? 'false' : 'true'; ?>;
        const bookingForm = document.querySelector('form.booking-form');

        function closeGuestPopup() {
            const popup = document.getElementById('loginPopup');
            if (popup) popup.style.display = 'none';
        }

        if (bookingForm) {
            bookingForm.addEventListener('submit', function (e) {
                if (guestBooking) {
                    e.preventDefault();
                    const popup = document.getElementById('loginPopup');
                    if (popup) popup.style.display = 'flex';
                    return;
                }

                const confirmed = confirm('Do you want to book now?');
                if (!confirmed) {
                    e.preventDefault();
                }
            });
        }
    </script>

<?php include "includes/footer.php"; ?>
import pathlib, re
root = pathlib.Path(r'c:\wamp64\www\hotel_website')
patterns = [
    re.compile(r'Import-Module', re.I),
    re.compile(r'Set-Location', re.I),
    re.compile(r'Cannot index into a null array', re.I),
    re.compile(r"module\s+'\?>'", re.I),
    re.compile(r'Could not be loaded', re.I),
    re.compile(r'\x00'),
    re.compile(r'\bPYTHON_OK\b')
]
found = False
print('SCANNING')
for path in sorted(root.rglob('*')):
    if path.suffix.lower() in {'.php', '.html', '.txt'} and path.is_file():
        text = path.read_text(encoding='utf-8', errors='ignore')
        for p in patterns:
            if p.search(text):
                print('MATCH', path.relative_to(root), p.pattern)
                found = True
if not found:
    print('NO_MATCHES')
